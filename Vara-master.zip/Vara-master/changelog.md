# Changelog

All notable changes to this project will be documented in this file.

## v1.2.0
* Fixed issues with Safari

## v1.1.5
* Added new font Parisienne

## v1.1.4
* Fixed issue with `.draw()` method.

## v1.1.3
* Added npm package
* Bug fixes

## v1.1.0

* Fixed bugs
* Improved accuracy of line breaks
* Added the method `.playAll()`

## v1.0.1

* Fixed height issue on firefox and edge
* Added `delay` property

## v1.0.0

* Initial release
